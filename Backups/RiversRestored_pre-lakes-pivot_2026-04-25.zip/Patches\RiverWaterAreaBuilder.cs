using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;
using TerrainGen;
using UnityEngine;

namespace RiversRestored.Patches
{
    /// <summary>
    /// Path-B "hybrid Pangu-style" support: registers each generated river as a
    /// real <c>TerrainGenerator+WaterArea</c> in <c>_generationData.waterAreas</c>,
    /// the same list FF uses for lakes/oceans.
    ///
    /// Why bother (vs. relying on the WaterPath ribbon alone):
    ///   * <c>waterAreas</c> IS serialized in the .map. Once we add a river
    ///     polygon there, FF restores it on save/reload automatically — no
    ///     manual respawn needed for the underlying water plane.
    ///   * <c>FishingManager</c> queries <c>waterAreas</c> for fishable bodies.
    ///     With rivers in the list, fishing nodes spawn naturally.
    ///   * The water-plane mesh covers the polygon at <c>waterHeight</c> on
    ///     both gen and reload, so we no longer get the "wide water on gen,
    ///     muddy strip on reload" mismatch when the heightmap dips below
    ///     waterHeight outside the WaterPath ribbon's coverage.
    ///
    /// The WaterPath ribbon stays — it's what gives the river its flow
    /// animation. The polygon water-plane provides the consistent base
    /// coverage; the ribbon rides on top to animate the flow.
    ///
    /// Polygon construction follows Pangu's pattern (TryBuildLakeWaterArea):
    /// rasterize the river path into a heightmap-resolution bool mask,
    /// scan for edge cells with their normal directions, build the WaterArea
    /// struct and append. Shaped like a thick line instead of Pangu's
    /// circle/rectangle.
    /// </summary>
    internal static class RiverWaterAreaBuilder
    {
        // Reflection caches — populated lazily on first call.
        private static Type? _waterAreaType;
        private static Type? _waterEdgeType;
        private static Type? _pairIntIntType;
        private static Type? _waterTypeType;
        private static FieldInfo? _faWaterType, _faPoints, _faEdge, _faShore, _faMinX, _faMinZ, _faMaxX, _faMaxZ;
        private static FieldInfo? _feX, _feZ, _feNx, _feNz;
        private static ConstructorInfo? _pairCtor;
        private static UnityEngine.Object? _cachedRiverWaterType;

        /// <summary>
        /// Build river WaterAreas from each entry in <c>_generationData.rivers</c>
        /// and append to <c>_generationData.waterAreas</c>. Idempotent — does
        /// nothing if the rivers list is empty or types aren't resolvable.
        /// </summary>
        /// <returns>Number of WaterAreas added.</returns>
        public static int BuildAndAddForAllRivers(TerrainGenerator tg, int innerRadius)
        {
            try
            {
                if (!ResolveTypes()) return 0;

                // ── Read map dimensions ──────────────────────────────────────
                var msField = AccessTools.Field(typeof(TerrainGenerator), "mapSettings");
                var ms = msField?.GetValue(tg);
                if (ms == null) { Log("BuildAndAddForAllRivers: mapSettings null"); return 0; }
                var msType = ms.GetType();
                int hmRes = (int)(msType.GetField("heightmapResolution")?.GetValue(ms) ?? 0);
                int mapW = (int)(msType.GetField("width")?.GetValue(ms) ?? 0);
                int mapD = (int)(msType.GetField("depth")?.GetValue(ms) ?? 0);
                if (hmRes <= 0 || mapW <= 0 || mapD <= 0)
                {
                    Log("BuildAndAddForAllRivers: invalid map dimensions");
                    return 0;
                }

                // ── Get rivers + waterAreas from generationData ──────────────
                var gdField = AccessTools.Field(typeof(TerrainGenerator), "_generationData");
                var gd = gdField?.GetValue(tg);
                if (gd == null) { Log("BuildAndAddForAllRivers: _generationData null"); return 0; }

                var riversField = gd.GetType().GetField("rivers",
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                var rivers = riversField?.GetValue(gd) as IList;
                if (rivers == null || rivers.Count == 0)
                {
                    Log("BuildAndAddForAllRivers: no rivers in _generationData");
                    return 0;
                }

                var waterAreasField = gd.GetType().GetField("waterAreas",
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                var waterAreas = waterAreasField?.GetValue(gd) as IList;
                if (waterAreas == null)
                {
                    Log("BuildAndAddForAllRivers: waterAreas list null");
                    return 0;
                }

                // ── Resolve a WaterType to use for the river polygon ─────────
                var waterType = ResolveRiverWaterType(tg);
                if (waterType == null)
                {
                    Log("BuildAndAddForAllRivers: no suitable WaterType found");
                    return 0;
                }

                // ── Build WaterArea(s) per river and append ──────────────────
                // FF spawns fishing nodes per WaterArea. Splitting each river
                // into multiple smaller polygons gives more nodes per length
                // of river — without changing the visual (water plane still
                // covers contiguous cells regardless of how many polygons we
                // split into).
                int chunkSize = RiversRestoredMod.RiverWaterAreaChunkSize?.Value ?? 25;
                int added = 0;
                for (int i = 0; i < rivers.Count; i++)
                {
                    var river = rivers[i];
                    if (river == null) continue;

                    var cpsField = river.GetType().GetField("points",
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                    var cps = cpsField?.GetValue(river) as IList;
                    if (cps == null || cps.Count < 2) continue;

                    // Decide chunk boundaries. 0 = one polygon for whole river.
                    int totalCps = cps.Count;
                    int effectiveChunk = (chunkSize <= 0 || chunkSize >= totalCps) ? totalCps : Mathf.Max(2, chunkSize);
                    int riverChunksAdded = 0;

                    for (int start = 0; start < totalCps - 1; start += effectiveChunk)
                    {
                        // Each chunk includes one cp of overlap with the next so
                        // the water plane has no gaps at chunk boundaries.
                        int end = Mathf.Min(start + effectiveChunk + 1, totalCps);
                        if (end - start < 2) break;

                        object? area = BuildOneRiverWaterArea(cps, start, end, hmRes, mapW, mapD, innerRadius, waterType);
                        if (area == null) continue;
                        waterAreas.Add(area);
                        added++;
                        riverChunksAdded++;

                        // (Don't log every chunk on dense rivers — too noisy.
                        //  Just summarize per-river.)
                    }
                    Log($"  river[{i}]: {totalCps} cps → {riverChunksAdded} WaterArea chunk(s) (chunkSize={effectiveChunk})");
                }

                Log($"BuildAndAddForAllRivers: appended {added} river WaterArea(s) to _generationData.waterAreas (now {waterAreas.Count} total)");
                return added;
            }
            catch (Exception ex)
            {
                Log($"BuildAndAddForAllRivers exception: {ex}");
                return 0;
            }
        }

        // ── Reflection setup ────────────────────────────────────────────────
        private static bool ResolveTypes()
        {
            if (_waterAreaType != null) return true;

            _waterAreaType = AccessTools.TypeByName("TerrainGen.TerrainGenerator+WaterArea");
            _waterEdgeType = AccessTools.TypeByName("TerrainGen.TerrainGenerator+WaterEdge");
            _waterTypeType = AccessTools.TypeByName("TerrainGen.WaterType");

            // Pair<int, int> — top-level generic
            var pairOpen = AccessTools.TypeByName("Pair`2");
            if (pairOpen != null)
                _pairIntIntType = pairOpen.MakeGenericType(typeof(int), typeof(int));

            if (_waterAreaType == null || _waterEdgeType == null || _pairIntIntType == null || _waterTypeType == null)
            {
                Log($"ResolveTypes failed: WaterArea={_waterAreaType != null} WaterEdge={_waterEdgeType != null} Pair={_pairIntIntType != null} WaterType={_waterTypeType != null}");
                return false;
            }

            _faWaterType = _waterAreaType.GetField("waterType");
            _faPoints = _waterAreaType.GetField("points");
            _faEdge = _waterAreaType.GetField("edge");
            _faShore = _waterAreaType.GetField("shore");
            _faMinX = _waterAreaType.GetField("minX");
            _faMinZ = _waterAreaType.GetField("minZ");
            _faMaxX = _waterAreaType.GetField("maxX");
            _faMaxZ = _waterAreaType.GetField("maxZ");

            _feX = _waterEdgeType.GetField("x");
            _feZ = _waterEdgeType.GetField("z");
            _feNx = _waterEdgeType.GetField("nx");
            _feNz = _waterEdgeType.GetField("nz");

            _pairCtor = _pairIntIntType.GetConstructor(new[] { typeof(int), typeof(int) });

            if (_pairCtor == null)
            {
                Log("ResolveTypes failed: Pair<int,int> constructor not found");
                return false;
            }
            return true;
        }

        /// <summary>
        /// Pick a WaterType to attach to the river polygon. Preference order:
        /// LakeSmall, Pond, Lake, then any non-ocean type. Cached after the
        /// first successful resolution.
        /// </summary>
        private static UnityEngine.Object? ResolveRiverWaterType(TerrainGenerator tg)
        {
            if (_cachedRiverWaterType != null) return _cachedRiverWaterType;
            try
            {
                var all = UnityEngine.Resources.FindObjectsOfTypeAll(_waterTypeType!);
                if (all == null || all.Length == 0) return null;

                string[] preferred = { "LakeSmall", "Pond", "Lake" };
                foreach (var name in preferred)
                {
                    foreach (var wt in all)
                    {
                        if (wt != null && string.Equals(wt.name, name, StringComparison.OrdinalIgnoreCase))
                        {
                            _cachedRiverWaterType = wt;
                            Log($"ResolveRiverWaterType: matched '{name}' for river polygons");
                            return wt;
                        }
                    }
                }

                // Fallback: first non-ocean type
                foreach (var wt in all)
                {
                    if (wt == null) continue;
                    string n = wt.name ?? "";
                    if (n.IndexOf("ocean", StringComparison.OrdinalIgnoreCase) >= 0) continue;
                    _cachedRiverWaterType = wt;
                    Log($"ResolveRiverWaterType: fallback to '{wt.name}'");
                    return wt;
                }
                return null;
            }
            catch (Exception ex)
            {
                Log($"ResolveRiverWaterType exception: {ex.Message}");
                return null;
            }
        }

        // ── Polygon construction ────────────────────────────────────────────
        /// <summary>Build a WaterArea polygon from a chunk of a river's
        /// control points (cps[startIdx ..endIdx - 1]). Pass startIdx = 0
        /// and endIdx = cps.Count for "whole river".</summary>
        private static object? BuildOneRiverWaterArea(IList cps, int startIdx, int endIdx,
                                                       int hmRes, int mapW, int mapD,
                                                       int radiusCells, UnityEngine.Object waterType)
        {
            try
            {
                if (cps == null || endIdx - startIdx < 2) return null;

                // Allocate full-size mask. We'll crop after we know bounds.
                bool[,] full = new bool[hmRes, hmRes];
                int gMinX = int.MaxValue, gMinZ = int.MaxValue;
                int gMaxX = int.MinValue, gMaxZ = int.MinValue;

                int prevHx = -1, prevHz = -1;
                bool havePrev = false;
                for (int idx = startIdx; idx < endIdx; idx++)
                {
                    var pt = cps[idx];
                    if (pt == null) continue;
                    if (!TryGetPointXZ(pt, out float wx, out float wz)) continue;
                    int hx = WorldToHmX(wx, mapW, hmRes);
                    int hz = WorldToHmZ(wz, mapD, hmRes);
                    if (havePrev)
                    {
                        BresenhamMarkDisc(full, hmRes, prevHx, prevHz, hx, hz, radiusCells,
                            ref gMinX, ref gMinZ, ref gMaxX, ref gMaxZ);
                    }
                    prevHx = hx; prevHz = hz;
                    havePrev = true;
                }

                if (gMinX > gMaxX || gMinZ > gMaxZ) return null;

                // Crop to bbox-sized mask
                int gw = gMaxX - gMinX + 1;
                int gh = gMaxZ - gMinZ + 1;
                bool[,] mask = new bool[gw, gh];
                for (int z = 0; z < gh; z++)
                    for (int x = 0; x < gw; x++)
                        mask[x, z] = full[gMinX + x, gMinZ + z];

                // Build edge and shore arrays. For each filled cell, check 4-neighbors.
                // If any neighbor is outside the mask, this cell is on the boundary.
                var edges = new List<object>();
                var shores = new List<object>();

                for (int m = gMinZ; m <= gMaxZ; m++)
                {
                    for (int n = gMinX; n <= gMaxX; n++)
                    {
                        int sx = n - gMinX, sz = m - gMinZ;
                        if (!mask[sx, sz]) continue;

                        bool n_w = IsMaskFilled(mask, gMinX, gMinZ, gMaxX, gMaxZ, n - 1, m);
                        bool n_e = IsMaskFilled(mask, gMinX, gMinZ, gMaxX, gMaxZ, n + 1, m);
                        bool n_s = IsMaskFilled(mask, gMinX, gMinZ, gMaxX, gMaxZ, n, m - 1);
                        bool n_n = IsMaskFilled(mask, gMinX, gMinZ, gMaxX, gMaxZ, n, m + 1);

                        if (!(n_w && n_e && n_s && n_n))
                        {
                            int nx = 0, nz = 0;
                            if (!n_w) nx--;
                            if (!n_e) nx++;
                            if (!n_s) nz--;
                            if (!n_n) nz++;
                            if (nx == 0 && nz == 0) nz = 1;

                            var edge = Activator.CreateInstance(_waterEdgeType!)!;
                            _feX!.SetValue(edge, n);
                            _feZ!.SetValue(edge, m);
                            _feNx!.SetValue(edge, nx);
                            _feNz!.SetValue(edge, nz);
                            edges.Add(edge);

                            var pair = _pairCtor!.Invoke(new object[] { n, m });
                            shores.Add(pair);
                        }
                    }
                }

                // Construct typed arrays (WaterEdge[], Pair<int,int>[])
                var edgesArr = Array.CreateInstance(_waterEdgeType!, edges.Count);
                for (int i = 0; i < edges.Count; i++) edgesArr.SetValue(edges[i], i);
                var shoresArr = Array.CreateInstance(_pairIntIntType!, shores.Count);
                for (int i = 0; i < shores.Count; i++) shoresArr.SetValue(shores[i], i);

                // Build WaterArea struct (boxed). FieldInfo.SetValue on a boxed
                // struct mutates the box; we set everything then return the box.
                object area = Activator.CreateInstance(_waterAreaType!)!;
                _faWaterType!.SetValue(area, waterType);
                _faPoints!.SetValue(area, mask);
                _faEdge!.SetValue(area, edgesArr);
                _faShore!.SetValue(area, shoresArr);
                _faMinX!.SetValue(area, gMinX);
                _faMinZ!.SetValue(area, gMinZ);
                _faMaxX!.SetValue(area, gMaxX);
                _faMaxZ!.SetValue(area, gMaxZ);

                return area;
            }
            catch (Exception ex)
            {
                Log($"BuildOneRiverWaterArea exception: {ex.Message}");
                return null;
            }
        }

        // ── Helpers ─────────────────────────────────────────────────────────
        private static void BresenhamMarkDisc(bool[,] mask, int hmRes,
                                                int x0, int z0, int x1, int z1, int radius,
                                                ref int minX, ref int minZ, ref int maxX, ref int maxZ)
        {
            int dx = Math.Abs(x1 - x0), dz = Math.Abs(z1 - z0);
            int sx = x0 < x1 ? 1 : -1, sz = z0 < z1 ? 1 : -1;
            int err = dx - dz;
            int x = x0, z = z0;
            int r2 = radius * radius;

            while (true)
            {
                for (int rz = -radius; rz <= radius; rz++)
                {
                    int cz = z + rz;
                    if (cz < 0 || cz >= hmRes) continue;
                    for (int rx = -radius; rx <= radius; rx++)
                    {
                        if (rx * rx + rz * rz > r2) continue;
                        int cx = x + rx;
                        if (cx < 0 || cx >= hmRes) continue;
                        if (!mask[cx, cz])
                        {
                            mask[cx, cz] = true;
                            if (cx < minX) minX = cx;
                            if (cx > maxX) maxX = cx;
                            if (cz < minZ) minZ = cz;
                            if (cz > maxZ) maxZ = cz;
                        }
                    }
                }
                if (x == x1 && z == z1) break;
                int e2 = err * 2;
                if (e2 > -dz) { err -= dz; x += sx; }
                if (e2 < dx) { err += dx; z += sz; }
            }
        }

        private static bool IsMaskFilled(bool[,] mask, int gMinX, int gMinZ, int gMaxX, int gMaxZ, int x, int z)
        {
            if (x < gMinX || x > gMaxX || z < gMinZ || z > gMaxZ) return false;
            return mask[x - gMinX, z - gMinZ];
        }

        private static int WorldToHmX(float wx, int mapW, int hmRes)
            => Mathf.Clamp(Mathf.RoundToInt(wx / mapW * (hmRes - 1)), 0, hmRes - 1);
        private static int WorldToHmZ(float wz, int mapD, int hmRes)
            => Mathf.Clamp(Mathf.RoundToInt(wz / mapD * (hmRes - 1)), 0, hmRes - 1);

        private static bool TryGetPointXZ(object pt, out float x, out float z)
        {
            x = 0; z = 0;
            try
            {
                Type t = pt.GetType();
                foreach (var name in new[] { "position", "pos", "worldPos", "worldPosition" })
                {
                    var f = t.GetField(name,
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                    if (f == null) continue;
                    var v = f.GetValue(pt);
                    if (v is Vector3 v3) { x = v3.x; z = v3.z; return true; }
                    if (v is Vector2 v2) { x = v2.x; z = v2.y; return true; }
                }
            }
            catch { }
            return false;
        }

        private static void Log(string msg) => RiversRestoredMod.Log.Msg($"[RR][WA] {msg}");
    }
}
